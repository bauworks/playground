<?php

if (!defined('ABSPATH')) exit;

global $wpdb;
// Constants
define('HEADLRESS_CMSIZE_PLUGIN_NAME', 'ヘッドレス CMSize');
define('HEADLRESS_CMSIZE_TABLE_NAME', $wpdb->prefix .'headless_cmsize_settings');